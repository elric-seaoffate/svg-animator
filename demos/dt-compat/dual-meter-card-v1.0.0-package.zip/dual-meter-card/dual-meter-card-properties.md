# Dual Meter Card — Widget Properties & Integration Guide

**Widget File:** `dual-meter-card.svg`  
**Format:** SVG Widget (Stage 16B Isolated Multi-Instance)  
**Scene Schema Version:** `1.2.0`  
**Protocol Version:** `1.0.0`  
**Generated At:** 2026-11-23 08:34:23 UTC  

---

## 1. Overview & Architecture

`Dual Meter Card` is a self-contained, collision-free SVG widget exported from **SVG Animator Studio**.
It encapsulates vector graphics, embedded animations, filter definitions, and an external parameter manifest.

- **Native Canvas Dimensions:** 380 × 170 px (viewBox `0 0 380 170`)
- **Isolation Model:** Element IDs, gradients, filters, and animation keyframes are automatically scoped per mounted instance.
- **Multi-Instance Capability:** Multiple copies of this widget can coexist inside the same HTML document or DOM tree with zero ID collisions or styling crosstalk.

## 2. Controllable Objects & Scene Inventory

The following inventory lists the visual objects authored within this widget and their corresponding external parameter bindings:

| Target Identifier | Object Name | Object Type | Geometry / Position | Layer | Bound Parameters |
|---|---|---|---|---|---|
| `group-3` | meter-a | Object Group (2 members) | Composite Group | Group | `meter-a-group-level` |
| `group-4` | meter-b | Object Group (2 members) | Composite Group | Group | `meter-b-group-level` |
| `group-5` | Dual Meter Card | Object Group (4 members) | Composite Group | Group | - |
| `lite-5` | cell-gauge Copy | Lite Effect (gauge-lite) | (136.0, 51.0) 210×24 | Lite | `meter-a-group-level` (value) |
| `lite-6` | cell-readout Copy | Lite Effect (text-lite) | (305.0, 51.0) 76×28 | Lite | `meter-a-group-level` (text) |
| `lite-7` | cell-gauge Copy-2 | Lite Effect (gauge-lite) | (136.0, 119.0) 210×24 | Lite | `meter-b-group-level` (value) |
| `lite-8` | cell-readout Copy-2 | Lite Effect (text-lite) | (305.0, 119.0) 76×28 | Lite | `meter-b-group-level` (text) |

---

## 3. Parameter Specification & API Reference

| Parameter Name | Type | Target | Property | Default | Permitted Limits / Values | Unit | Description |
|---|---|---|---|---|---|---|---|
| **`meter-a-group-level`** | `number` | `group-3` | `value` | 42 | 0.0 to 100.0 | % | Primary Level on group meter-a (2 mapped target(s)) → Fan-out: `lite-5.value`, `lite-6.text` |
| **`meter-b-group-level`** | `number` | `group-4` | `value` | 42 | 0.0 to 100.0 | % | Primary Level on group meter-b (2 mapped target(s)) → Fan-out: `lite-7.value`, `lite-8.text` |

---

## 4. Animation & Transport Capabilities

SVG Animator Studio distinguishes between authored animation loops and external host controls:

- **Connector Flows, Optical Glows & Ripples:** Run continuously via browser-native SVG animation engines.
- **Instance Animation Playback Control:**
  - `widget.play()`: Resumes/plays all animations within the instance.
  - `widget.pause()`: Freezes SMIL and CSS animations for the instance only.
  - `widget.setSpeed(multiplier)`: Scales playback speed (`0.1` to `5.0`) on supported animations.
  - `widget.resetParameters()`: Restores all bound properties to authored scene defaults.
  - Individual instance playback does **not** interfere with other instances on the same page.

---

## 5. No-Code Usage Guide (For Non-Programmers)

This widget package includes a pre-built interactive control studio:

1. Locate `demo.html` in this package directory.
2. Double-click `demo.html` to open it in any modern browser (Chrome, Edge, Firefox, Safari).
3. The page automatically mounts **three independent instances** (Unit A, Unit B, Unit C).
4. Adjust the sliders, color pickers, and toggles in each panel. Each instance responds instantly.
5. Use the **Reset** button to restore defaults, or **Pause/Play** to freeze/resume animations.
6. No web server, command line, or code editing is required.

---

## 6. Developer Integration & JavaScript API Reference

### Mounting in a Web Application

```html
<!-- 1. Include the lightweight Stage 16B widget runtime -->
<script src="js/svg-widget.js"></script>

<!-- 2. Target container element -->
<div id="dual-meter-card-container" style="width: 400px; height: 320px;"></div>

<script>
  // 3. Mount instance (offline file:// supported via inline template/markup or HTTP URL)
  const svgSource = document.getElementById('dual-meter-card-template') ? document.getElementById('dual-meter-card-template').innerHTML : 'dual-meter-card.svg';
  const myWidget = SVGWidget.mount('#dual-meter-card-container', svgSource, {
    instanceId: 'dual-meter-card-1'
  });
</script>
```

### Controlling Instance Parameters

```javascript
// Single parameter update (using real exported parameter 'meter-a-group-level'):
myWidget.setParameter('meter-a-group-level', 42);

// Atomic batch update:
myWidget.setParameters({
  meter-a-group-level: 42,
  meter-b-group-level: 42,
});

// Read current value:
const val = myWidget.getParameter('meter-a-group-level');

// Reset to authored defaults:
myWidget.resetParameters();

// Listen for property changes:
myWidget.on('change', (evt) => {
  console.log(`[${evt.instanceId}] ${evt.name} changed to:`, evt.value);
});
```

### Multi-Instance Independence Example

```javascript
const svgSource = document.getElementById('dual-meter-card-template') ? document.getElementById('dual-meter-card-template').innerHTML : 'dual-meter-card.svg';

const instA = SVGWidget.mount('#unitA', svgSource, { instanceId: 'unit-a' });
const instB = SVGWidget.mount('#unitB', svgSource, { instanceId: 'unit-b' });
const instC = SVGWidget.mount('#unitC', svgSource, { instanceId: 'unit-c' });

instA.setParameter('meter-a-group-level', 100.0); // High value
instB.setParameter('meter-a-group-level', 50.0);  // Mid value
instC.setParameter('meter-a-group-level', 0.0);  // Low value
```

---

*(End of Guide — Generated automatically by SVG Animator Studio)*
