# Dual Meter Card — Portable SVG Widget Package

This directory contains a complete, portable, and ready-to-run SVG widget package exported from **SVG Animator Studio**.

## Quick Start

1. **Interactive Demo (No-Code):** Double-click `demo.html` in your browser. You can operate three independent live instances immediately with real-time controls.
2. **Standalone Asset:** `dual-meter-card.svg` is the collision-free SVG file ready to embed in any web application.
3. **Properties Guide:** Read `dual-meter-card-properties.md` for complete parameter specifications, object inventory, and integration code snippets.

## Package File Index

| File | Purpose |
|---|---|
| `dual-meter-card.svg` | Isolated, collision-free SVG widget with embedded JSON parameter manifest |
| `dual-meter-card-properties.md` | Authoritative properties guide, object inventory, and developer reference |
| `widget-manifest.json` | Inspection copy of the validated parameter manifest schema |
| `demo.html` | Ready-to-run interactive multi-instance no-code control page |
| `js/svg-widget.js` | Lightweight, dependency-free JavaScript runtime adapter |
| `README.md` | This quick start and package index |

**Total Exposed Parameters:** 2  
**Format Specification:** Stage 16B Isolated Multi-Instance Widget  
**Runtime Compatibility:** Universal (Browser Global, ES Modules, CommonJS)  
